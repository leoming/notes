package com.example.syberos.demo1;

import android.app.Activity;
import android.content.Context;
import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.widget.EditText;

import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.util.Map;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        EditText textEdit = new EditText(this);
        setContentView(textEdit);
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        // hook
        HookHelper.hookClicpBoard(MainActivity.this);
    }
}

class HookHelper {
    public static void hookClicpBoard(Object obj) {
        try {
            Class<?> serviceManagerClass = Class.forName("android.os.ServiceManager");
            Method getServiceMethod = serviceManagerClass.getDeclaredMethod("getService", String.class);
            Object primeBinder = getServiceMethod.invoke(null, "clipboard");
            
            Field sCacheField = serviceManagerClass.getDeclaredField("sCache");
            sCacheField.setAccessible(true);
            Map<String, IBinder> sCacheMap = (Map<String, IBinder>) sCacheField.get(null);
            sCacheMap.put("clipboard", (IBinder)Proxy.newProxyInstance(obj.getClass().getClassLoader(), 
                        new Class[]{IBinder.class}, new IBinderHandler(primeBinder)));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

class IBinderHandler implements InvocationHandler {
    Object mBaseBinderProxy;
    public IBinderHandler(Object base) {
        mBaseBinderProxy = base;
    }
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        if (method.getName().equals("queryLocalInterface")) {
            // todo return IClipBoardHandlerProxy;
            return Proxy.newProxyInstance(proxy.getClass().getClassLoader(), 
                    new Class[]{Class.forName("android.content.IClipboard")}, new IClipBoardHandler(mBaseBinderProxy));
        }
        return method.invoke(mBaseBinderProxy, args);
    }
}

class IClipBoardHandler implements InvocationHandler {
    Object mBaseClipBoardBinder;
    public IClipBoardHandler(Object binderProxy) {
        try {
        Class<?> IClipboard$StubClass = Class.forName("android.content.IClipboard$Stub");
        Method asInterfaceMethod = IClipboard$StubClass.getDeclaredMethod("asInterface", IBinder.class);
        mBaseClipBoardBinder = asInterfaceMethod.invoke(null, binderProxy);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        if (method.getName().equals("getPrimaryClip")) {
            return ClipData.newPlainText("----hook data----", "hooked Clipboard!!!");
        }
        if (method.getName().equals("hasPrimaryClip")) {
            return true;
        }
        return method.invoke(mBaseClipBoardBinder, args);
    }
    
}
