package com.example.syberos.demo4;

import android.content.Intent;
import android.os.IBinder;
import android.app.Service;
import android.util.Log;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Binder;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.List;



public class ServiceManager {
    private static String TAG = "zmm";

    private static ServiceManager sInstance;
    private Map<String, Service> mServiceMap = new HashMap<String, Service>();

    public synchronized static ServiceManager getInstance() {
        if (sInstance == null) {
            sInstance = new ServiceManager();
        }
        return sInstance;
    }

    public ServiceManager() {
    }


    public void onStart(Intent proxyIntent, int startId) {
        Intent targetIntent = proxyIntent.getParcelableExtra("TargetService");
        ServiceInfo serviceInfo = selectPluginService(targetIntent);
        if (serviceInfo == null) {
            Log.d(TAG, "onStart can not found service: " + targetIntent.getComponent());
            return;
        }
        Log.d(TAG, "serviceInfo.name = " + serviceInfo.name);
        Log.d(TAG, "serviceInfo.processName = " + serviceInfo.processName);
        Log.d(TAG, "serviceInfo.packageName = " + serviceInfo.packageName);
        try {
            if (!mServiceMap.containsKey(serviceInfo.name)) {
                proxyCreateService(serviceInfo);
            }

            Log.d(TAG, "mServiceMap.size = " + mServiceMap.size());
            Service service = mServiceMap.get(serviceInfo.name);
            if (service == null) {
                Log.d(TAG, "createService error!");
                return;
            }
            Log.d(TAG, "plugin service" + service);
            service.onStart(targetIntent, startId);
        } catch (Exception e) {
            Log.d(TAG, "get Exception");
            Log.d(TAG, "e = " + e);
            Log.e(TAG, Log.getStackTraceString(e));
        }
    }

    public int stopService(Intent targetIntent) {
        ServiceInfo serviceInfo = selectPluginService(targetIntent);
        if (serviceInfo == null) {
            Log.d(TAG, "stopService can not found service: " + targetIntent.getComponent());
            return 0;
        }
        Service service = mServiceMap.get(serviceInfo.name);
        if (service == null) {
            Log.d(TAG, "can not found service, is alive ? "); 
            return 0;
        }
        service.onDestroy();
        mServiceMap.remove(serviceInfo.name);
        if (mServiceMap.isEmpty()) {
            // kill ProxyService
        }
        return 1;
    }

    private ServiceInfo selectPluginService(Intent intent) {
        for (ComponentName componentName : LoadedApkClassLoaderHookHelper.sServiceInfoMap.keySet()) {
            if (componentName.equals(intent.getComponent())) {
                return LoadedApkClassLoaderHookHelper.sServiceInfoMap.get(componentName);
            }
        }
        return null;
    }

    private void proxyCreateService(ServiceInfo serviceInfo) throws Exception {
        Log.d("zmm", "proxyCreateService()"); 
        IBinder token = new Binder();

        Class<?> createServiceDataClass = Class.forName("android.app.ActivityThread$CreateServiceData");
        Constructor<?> constructor = createServiceDataClass.getDeclaredConstructor();
        constructor.setAccessible(true);
        Object createServiceData = constructor.newInstance();
        //Log.d(TAG, "createServiceData = " + createServiceData);

        Field tokenField = createServiceDataClass.getDeclaredField("token");
        tokenField.setAccessible(true);
        tokenField.set(createServiceData, token);

        //serviceInfo.applicationInfo.packageName = "com.example.syberos.intercept_activity";
        Field infoField = createServiceDataClass.getDeclaredField("info");
        infoField.setAccessible(true);
        infoField.set(createServiceData, serviceInfo);

        Class<?> compatibilityClass = Class.forName("android.content.res.CompatibilityInfo");
        Field defaultCompatibilityField = compatibilityClass.getDeclaredField("DEFAULT_COMPATIBILITY_INFO");
        defaultCompatibilityField.setAccessible(true);
        Object defaultCompatibility = defaultCompatibilityField.get(null);
        Field compatInfoField = createServiceDataClass.getDeclaredField("compatInfo");
        compatInfoField.setAccessible(true);
        compatInfoField.set(createServiceData, defaultCompatibility);

        // createServiceData construct end

        Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
        Method currentActivityThreadMethod = activityThreadClass.getDeclaredMethod("currentActivityThread");
        currentActivityThreadMethod.setAccessible(true);
        Object currentActivityThread = currentActivityThreadMethod.invoke(null);

        Field mServicesField = activityThreadClass.getDeclaredField("mServices");
        mServicesField.setAccessible(true);
        Map mServices = (Map)mServicesField.get(currentActivityThread);
        // InvocationTargetException
        Log.d("zmm", "proxyCreateService() mServices.size = " + mServices.size());
        Method handleCreateServiceMethod = activityThreadClass.getDeclaredMethod("handleCreateService", createServiceDataClass);
        handleCreateServiceMethod.setAccessible(true);
        handleCreateServiceMethod.invoke(currentActivityThread, createServiceData);

        Log.d("zmm", "proxyCreateService() mServices.size = " + mServices.size());
        Service service = (Service)mServices.get(token);

        mServices.remove(token);

        mServiceMap.put(serviceInfo.name, service);
    }

}
