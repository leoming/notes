package com.example.syberos.demo4;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.pm.ApplicationInfo;
import android.util.Log;
import android.content.pm.ActivityInfo;
import android.content.IntentFilter;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.os.Handler;
import android.os.Message;
import android.os.IBinder;
import android.util.IntProperty;

import java.util.List;
import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class MainActivity extends Activity {
    private Intent mLaunchIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Button button = new Button(this);
        button.setText("StartApp");
        setContentView(button);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                try {
                    startActivity(mLaunchIntent);
                } catch (Exception e) {
                    Log.d("zmm", "e = " + e);
                }
            }
        });
    }

    @Override
    protected void attachBaseContext(Context baseContext) {
        super.attachBaseContext(baseContext);

        try {
            Util.extractAssets(this, "hello.apk");
            mLaunchIntent = LoadedApkClassLoaderHookHelper.loadApkAndGetLaunchIntent(getFileStreamPath("hello.apk"));
        } catch (Exception e) {
            e.printStackTrace();
        }

        HookHelper.hookActivityManager();
        HookHelper.hookHandlerCallback();
    }
}

class HookHelper {
    public static void hookActivityManager() {
        try {
            Class<?> activityManagerNativeClass = Class.forName("android.app.ActivityManagerNative");
            Field gDefaultFeild = activityManagerNativeClass.getDeclaredField("gDefault");
            gDefaultFeild.setAccessible(true);
            Object gDefault = gDefaultFeild.get(null);

            Class<?> singleTonClass = Class.forName("android.util.Singleton");
            Field mInstanceField = singleTonClass.getDeclaredField("mInstance");
            mInstanceField.setAccessible(true);
            Object activityManager = mInstanceField.get(gDefault);
            mInstanceField.set(gDefault, Proxy.newProxyInstance(activityManagerNativeClass.getClassLoader(),
                    new Class[]{Class.forName("android.app.IActivityManager")},
                    new IActivityManagerHandler(activityManager)));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    public static void hookHandlerCallback() {
        try {
            Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
            Field sActivityThreadFiled = activityThreadClass.getDeclaredField("sCurrentActivityThread");
            sActivityThreadFiled.setAccessible(true);
            Object sCurrentActivityThread = sActivityThreadFiled.get(null);

            Field mHField = activityThreadClass.getDeclaredField("mH");
            mHField.setAccessible(true);
            Object mH = mHField.get(sCurrentActivityThread);

            Class<?> handlerClass = Class.forName("android.os.Handler");
            Field callbackField = handlerClass.getDeclaredField("mCallback");
            callbackField.setAccessible(true);
            callbackField.set(mH, new ActivityThreadHandlerCallback());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

class IActivityManagerHandler implements InvocationHandler {
    Object mBase;
    public IActivityManagerHandler(Object base) {
        mBase = base;
    }


    @Override
    public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
        if (method.getName().equals("startActivity")) {
            for (int i = 0; i < objects.length; ++i) {
                if (objects[i] instanceof Intent) {
                    Intent targetIntent = (Intent)objects[i];
                    Intent newIntent = new Intent();
                    newIntent.setComponent(new ComponentName("com.example.syberos.demo4",
                            StubActivity.class.getName()));
                    newIntent.putExtra("TargetActivity", targetIntent);
                    objects[i] = newIntent;
                    break;
                }
            }
        }
        if (method.getName().equals("startService")) {
            Log.d("zmm", "startService hooked");
            for (int i = 0; i < objects.length; ++i) {
                if (objects[i] instanceof Intent) {
                    Intent targetIntent = (Intent)objects[i];
                    Intent newIntent = new Intent();
                    newIntent.setComponent(new ComponentName("com.example.syberos.demo4",
                            ProxyService.class.getName()));
                    newIntent.putExtra("TargetService", targetIntent);
                    objects[i] = newIntent;
                    break;
                }
            }
        } 
        if (method.getName().equals("stopService")) {
            for (int i = 0; i < objects.length; ++i) {
                if (objects[i] instanceof Intent) {
                    Intent targetIntent = (Intent)objects[i];
                    if (!targetIntent.getComponent().getPackageName().equals("com.example.syberos.demo4")) {
                        return ServiceManager.getInstance().stopService(targetIntent);
                    }
                    break;
                }
            }
        }
        if (method.getName().equals("serviceDoneExecuting")) {
            return new Object();
        }

        return method.invoke(mBase, objects);
    }

}

class ActivityThreadHandlerCallback implements Handler.Callback {
    static public IBinder token;
    @Override
    public boolean handleMessage(Message message) {
        if (message.what == 100) {
            Object obj = message.obj;
            try {
                Field intent = obj.getClass().getDeclaredField("intent");
                intent.setAccessible(true);
                Intent stubIntent = (Intent)intent.get(obj);
                Intent targetIntent = stubIntent.getParcelableExtra("TargetActivity");
                stubIntent.setComponent(targetIntent.getComponent());

                Field activityInfoField = obj.getClass().getDeclaredField("activityInfo");
                Log.d("zmm", "110 className = " + obj.getClass().getCanonicalName());
                activityInfoField.setAccessible(true);
                ActivityInfo activityInfo = (ActivityInfo) activityInfoField.get(obj);
                activityInfo.applicationInfo.packageName = targetIntent.getPackage() == null ?
                        targetIntent.getComponent().getPackageName() : targetIntent.getPackage();
                hookPackageManager();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public static void hookPackageManager() throws Exception {
        Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
        Method currentActivityThreadMethod = activityThreadClass.getDeclaredMethod("currentActivityThread");
        currentActivityThreadMethod.setAccessible(true);
        Object currentActivityThread = currentActivityThreadMethod.invoke(null);

        Field sPackageManagerField = activityThreadClass.getDeclaredField("sPackageManager");
        sPackageManagerField.setAccessible(true);
        Object sPackageManager = sPackageManagerField.get(currentActivityThread);

        Class<?> iPackageManagerInterface = Class.forName("android.content.pm.IPackageManager");
        Object porxy = Proxy.newProxyInstance(iPackageManagerInterface.getClassLoader(),
                new Class<?>[]{iPackageManagerInterface}, new IPackageManagerHookHandler(sPackageManager));
        sPackageManagerField.set(currentActivityThread, porxy);

    }
}

class IPackageManagerHookHandler implements InvocationHandler {
    Object mBase;
    IPackageManagerHookHandler(Object base) {
        mBase = base;
    }
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        if (method.getName().equals("getPackageInfo")) {
            PackageInfo packageInfo = new PackageInfo();
            
            Log.d("zmm", "args[0] = " + args[0]);
            Log.d("zmm", "packageInfo = " + packageInfo);
            Log.d("zmm", "packageInfo.packageName = " + packageInfo.packageName);
            return packageInfo;
        }
        return method.invoke(mBase, args);
    }
}
