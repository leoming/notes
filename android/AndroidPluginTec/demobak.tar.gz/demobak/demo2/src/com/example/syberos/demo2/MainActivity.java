package com.example.syberos.demo2;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.content.ComponentName;
import android.widget.Button;
import android.view.View;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import java.lang.reflect.*;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        Button btn = new Button(this);
        btn.setText("Start StubActivity");

        setContentView(btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.this.startActivity(new Intent(MainActivity.this, TargetActivity.class));
            }
        });
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        try {
            HookHelper.hook();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

class HookHelper {
    public static Object activityManager;
    public static void hook() throws Exception {
         Class<?> ActivityManagerNativeClass = Class.forName("android.app.ActivityManagerNative");
         Method getDefaultMethod = ActivityManagerNativeClass.getDeclaredMethod("getDefault");
         activityManager = getDefaultMethod.invoke(null);
         Field gDefaultFeild = ActivityManagerNativeClass.getDeclaredField("gDefault");
         gDefaultFeild.setAccessible(true);
         Object gDefaultObj = gDefaultFeild.get(null);
         Class<?> SingletonClass = Class.forName("android.util.Singleton");
         Field mInstanceField = SingletonClass.getDeclaredField("mInstance");
         mInstanceField.setAccessible(true);
         
         mInstanceField.set(gDefaultObj, Proxy.newProxyInstance(HookHelper.class.getClassLoader(), 
                     new Class[]{ Class.forName("android.app.IActivityManager")}, new IActivityManagerHandler(activityManager)));

         Class<?> ActivityThreadClass = Class.forName("android.app.ActivityThread");
         Method currentActivityThreadMethod = ActivityThreadClass.getDeclaredMethod("currentActivityThread");
         Object activityThread = currentActivityThreadMethod.invoke(null);
         Field mHField = ActivityThreadClass.getDeclaredField("mH");
         mHField.setAccessible(true);
         Object mH = mHField.get(activityThread);
         Field mCallbackField = Handler.class.getDeclaredField("mCallback");
         mCallbackField.setAccessible(true);
         mCallbackField.set(mH, new ActivityThreadHandlerCallback());
    }
}

/*
 *getParcelableExtra(String)
 
 public Intent putExtra(String name, Parcelable value) {
 * */
class IActivityManagerHandler implements InvocationHandler {
    public Object mBase;
    public IActivityManagerHandler(Object base) {
        mBase = base;
    }
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        if (method.getName().equals("startActivity")) {
            for (int i = 0; i < args.length; ++i) {
                Object obj = args[i];
                if (obj instanceof Intent) {
                    Intent target = (Intent) obj;
                    Intent stubIntent = new Intent();
                    stubIntent.setComponent(new ComponentName("com.example.syberos.demo2", "com.example.syberos.demo2.StubActivity"));
                    stubIntent.putExtra("TargetIntent", target);
                    args[i] = stubIntent;
                    break;
                }
            }
        }
        return method.invoke(mBase, args);
    }
}

class ActivityThreadHandlerCallback implements Handler.Callback {
    @Override
    public boolean handleMessage(Message msg) {
        switch (msg.what) {
            case 100:
                handleActivity(msg);
                break;
        }
        return false;
    }
    private void handleActivity(Message msg) {
        try {
            Object obj = msg.obj;
            Field intentField = obj.getClass().getDeclaredField("intent");
            intentField.setAccessible(true);
            Intent stubIntent = (Intent)intentField.get(obj);
            Intent targetIntent = (Intent)stubIntent.getParcelableExtra("TargetIntent");
            intentField.set(obj, targetIntent);
            //stubIntent.setComponent(targetIntent.getComponent());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
