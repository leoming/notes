package com.example.syberos.demo2;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.widget.TextView;
import android.view.View;

public class StubActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        TextView tv = new TextView(this);
        tv.setText("StubActivity");

        setContentView(tv);
    }
}
