package com.example.syberos.demo5;

import android.app.Application;
import android.content.Context;
import android.content.ComponentName;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.pm.ApplicationInfo;
import android.util.Log;
import android.content.pm.ActivityInfo;
import android.content.IntentFilter;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.os.Handler;
import android.os.Message;
import android.os.IBinder;
import android.util.IntProperty;

import java.util.List;
import java.lang.reflect.*;

public class MyApplication extends Application {
    private static Context sContext;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        sContext = base;
        if (isPluginProcess(base)) {
	        try {
	            Util.extractAssets(this, "hello.apk");
	            LoadedApkClassLoaderHookHelper.loadApkAndGetLaunchIntent(getFileStreamPath("hello.apk"));
                Class<?> ProcessClass = Class.forName("android.os.Process");
                Method setArgV0Method = ProcessClass.getDeclaredMethod("setArgV0", String.class);
		        Log.d("zmm", "LoadedApkClassLoaderHookHelper.processName = " + LoadedApkClassLoaderHookHelper.processName);
                setArgV0Method.invoke(null, LoadedApkClassLoaderHookHelper.processName);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        HookHelper2.hookActivityManager();
	        HookHelper2.hookHandlerCallback();
	    }
    }

    public static Context getContext() {
        return sContext;
    }
    private boolean isPluginProcess(Context context) {
    	ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
		List<RunningAppProcessInfo> infos = activityManager.getRunningAppProcesses();
		if (infos == null)
		  return false;
		String sCurrentProcessName = null;
		for (RunningAppProcessInfo info : infos) {
		  if (info.pid == android.os.Process.myPid()) {
		      sCurrentProcessName = info.processName;
		      Log.d("zmm", "info.processName = " + info.processName);
		      break;
		  }
		}
		Log.d("zmm", "sCurrentProcessName = " + sCurrentProcessName);
		Log.d("zmm", "context.getPackageName = " + context.getPackageName());
		return !context.getPackageName().equals(sCurrentProcessName);	
    }
}

class HookHelper2 {
    public static void hookActivityManager() {
        try {
            Class<?> activityManagerNativeClass = Class.forName("android.app.ActivityManagerNative");
            Field gDefaultFeild = activityManagerNativeClass.getDeclaredField("gDefault");
            gDefaultFeild.setAccessible(true);
            Object gDefault = gDefaultFeild.get(null);

            Class<?> singleTonClass = Class.forName("android.util.Singleton");
            Field mInstanceField = singleTonClass.getDeclaredField("mInstance");
            mInstanceField.setAccessible(true);
            Object activityManager = mInstanceField.get(gDefault);
            mInstanceField.set(gDefault, Proxy.newProxyInstance(activityManagerNativeClass.getClassLoader(),
                    new Class[]{Class.forName("android.app.IActivityManager")},
                    new IActivityManagerHandler2(activityManager)));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    public static void hookHandlerCallback() {
        try {
            Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
            Field sActivityThreadFiled = activityThreadClass.getDeclaredField("sCurrentActivityThread");
            sActivityThreadFiled.setAccessible(true);
            Object sCurrentActivityThread = sActivityThreadFiled.get(null);

            Field mHField = activityThreadClass.getDeclaredField("mH");
            mHField.setAccessible(true);
            Object mH = mHField.get(sCurrentActivityThread);

            Class<?> handlerClass = Class.forName("android.os.Handler");
            Field callbackField = handlerClass.getDeclaredField("mCallback");
            callbackField.setAccessible(true);
            callbackField.set(mH, new ActivityThreadHandlerCallback2());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

class IActivityManagerHandler2 implements InvocationHandler {
    Object mBase;
    public IActivityManagerHandler2(Object base) {
        mBase = base;
    }


    @Override
    public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
        if (method.getName().equals("startActivity")) {
            for (int i = 0; i < objects.length; ++i) {
                if (objects[i] instanceof Intent) {
                    Intent targetIntent = (Intent)objects[i];
                    Intent newIntent = new Intent();
                    newIntent.setComponent(new ComponentName("com.example.syberos.demo5",
                            StubActivity.class.getName()));
                    newIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    newIntent.putExtra("TargetActivity", targetIntent);
                    objects[i] = newIntent;
                    break;
                }
            }
        }
        if (method.getName().equals("startService")) {
            Log.d("zmm", "startService hooked");
            for (int i = 0; i < objects.length; ++i) {
                if (objects[i] instanceof Intent) {
                    Intent targetIntent = (Intent)objects[i];
                    Intent newIntent = new Intent();
                    newIntent.setComponent(new ComponentName("com.example.syberos.demo5",
                            ProxyService.class.getName()));
                    newIntent.putExtra("TargetService", targetIntent);
                    objects[i] = newIntent;
                    break;
                }
            }
        } 
        if (method.getName().equals("stopService")) {
            for (int i = 0; i < objects.length; ++i) {
                if (objects[i] instanceof Intent) {
                    Intent targetIntent = (Intent)objects[i];
                    if (!targetIntent.getComponent().getPackageName().equals("com.example.syberos.demo5")) {
                        return ServiceManager.getInstance().stopService(targetIntent);
                    }
                    break;
                }
            }
        }
        if (method.getName().equals("serviceDoneExecuting")) {
            return new Object();
        }

        return method.invoke(mBase, objects);
    }

}

class ActivityThreadHandlerCallback2 implements Handler.Callback {
    @Override
    public boolean handleMessage(Message message) {
        if (message.what == 100) {
            Object obj = message.obj;
            try {
                Field intent = obj.getClass().getDeclaredField("intent");
                intent.setAccessible(true);
                Intent stubIntent = (Intent)intent.get(obj);
                Intent targetIntent = stubIntent.getParcelableExtra("TargetActivity");
                stubIntent.setComponent(targetIntent.getComponent());

                Field activityInfoField = obj.getClass().getDeclaredField("activityInfo");
                Log.d("zmm", "110 className = " + obj.getClass().getCanonicalName());
                activityInfoField.setAccessible(true);
                ActivityInfo activityInfo = (ActivityInfo) activityInfoField.get(obj);
                activityInfo.applicationInfo.packageName = targetIntent.getPackage() == null ?
                        targetIntent.getComponent().getPackageName() : targetIntent.getPackage();
                hookPackageManager();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    public static void hookPackageManager() throws Exception {
        Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
        Method currentActivityThreadMethod = activityThreadClass.getDeclaredMethod("currentActivityThread");
        currentActivityThreadMethod.setAccessible(true);
        Object currentActivityThread = currentActivityThreadMethod.invoke(null);

        Field sPackageManagerField = activityThreadClass.getDeclaredField("sPackageManager");
        sPackageManagerField.setAccessible(true);
        Object sPackageManager = sPackageManagerField.get(currentActivityThread);

        Class<?> iPackageManagerInterface = Class.forName("android.content.pm.IPackageManager");
        Object porxy = Proxy.newProxyInstance(iPackageManagerInterface.getClassLoader(),
                new Class<?>[]{iPackageManagerInterface}, new IPackageManagerHookHandler2(sPackageManager));
        sPackageManagerField.set(currentActivityThread, porxy);

    }
}

class IPackageManagerHookHandler2 implements InvocationHandler {
    Object mBase;
    IPackageManagerHookHandler2(Object base) {
        mBase = base;
    }
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        if (method.getName().equals("getPackageInfo")) {
            PackageInfo packageInfo = new PackageInfo();
            return packageInfo;
        }
        return method.invoke(mBase, args);
    }
}
