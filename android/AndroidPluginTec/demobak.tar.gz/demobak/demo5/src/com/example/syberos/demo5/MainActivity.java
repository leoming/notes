package com.example.syberos.demo5;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.pm.ApplicationInfo;
import android.util.Log;
import android.content.pm.ActivityInfo;
import android.content.IntentFilter;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.os.Handler;
import android.os.Message;
import android.os.IBinder;
import android.util.IntProperty;

import java.util.List;
import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class MainActivity extends Activity {
    private Intent mLaunchIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Button button = new Button(this);
        button.setText("StartApp");
        setContentView(button);

        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                try {
                    mLaunchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(mLaunchIntent);
                } catch (Exception e) {
                    Log.d("zmm", "e = " + e);
                }
            }
        });
    }

    @Override
    protected void attachBaseContext(Context baseContext) {
        super.attachBaseContext(baseContext);

        try {
            Util.extractAssets(this, "hello.apk");
            mLaunchIntent = LoadedApkClassLoaderHookHelper.loadApkAndGetLaunchIntent(getFileStreamPath("hello.apk"));
        } catch (Exception e) {
            e.printStackTrace();
        }

        HookHelper.hookActivityManager();
    }
}

class HookHelper {
    public static void hookActivityManager() {
        try {
            Class<?> activityManagerNativeClass = Class.forName("android.app.ActivityManagerNative");
            Field gDefaultFeild = activityManagerNativeClass.getDeclaredField("gDefault");
            gDefaultFeild.setAccessible(true);
            Object gDefault = gDefaultFeild.get(null);

            Class<?> singleTonClass = Class.forName("android.util.Singleton");
            Field mInstanceField = singleTonClass.getDeclaredField("mInstance");
            mInstanceField.setAccessible(true);
            Object activityManager = mInstanceField.get(gDefault);
            mInstanceField.set(gDefault, Proxy.newProxyInstance(activityManagerNativeClass.getClassLoader(),
                    new Class[]{Class.forName("android.app.IActivityManager")},
                    new IActivityManagerHandler(activityManager)));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}

class IActivityManagerHandler implements InvocationHandler {
    Object mBase;
    public IActivityManagerHandler(Object base) {
        mBase = base;
    }


    @Override
    public Object invoke(Object o, Method method, Object[] objects) throws Throwable {
        if (method.getName().equals("startActivity")) {
            for (int i = 0; i < objects.length; ++i) {
                if (objects[i] instanceof Intent) {
                    Intent targetIntent = (Intent)objects[i];
                    Intent newIntent = new Intent();
                    newIntent.setComponent(new ComponentName("com.example.syberos.demo5",
                            StubActivity.class.getName()));
                    newIntent.putExtra("TargetActivity", targetIntent);
                    objects[i] = newIntent;
                    break;
                }
            }
        }       

        return method.invoke(mBase, objects);
    }

}
