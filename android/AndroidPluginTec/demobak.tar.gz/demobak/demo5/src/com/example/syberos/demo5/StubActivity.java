package com.example.syberos.demo5;

import android.app.Activity;

public class StubActivity extends Activity {
}
