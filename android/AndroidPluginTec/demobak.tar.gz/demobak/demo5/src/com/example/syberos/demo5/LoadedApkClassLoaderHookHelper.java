package com.example.syberos.demo5;

import java.io.File;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

import android.content.pm.ApplicationInfo;
import android.util.Log;
import android.content.Intent;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.ServiceInfo;
import android.content.pm.ProviderInfo;
import dalvik.system.DexClassLoader;

class CustomClassLoader extends DexClassLoader {
    public CustomClassLoader(String dexPath, String optimizedDirectory, String libPath, ClassLoader parent) {
        super(dexPath, optimizedDirectory, libPath, parent);
    }
}

public class LoadedApkClassLoaderHookHelper {

    public static  Map<String, Object> sLoadedApk = new HashMap<String, Object>();
    public static  Map<String, ClassLoader> sLoadedClassLoaders = new HashMap<String, ClassLoader>();
    public static  Map<ActivityInfo, List<? extends IntentFilter> > sActivityFiltersCache = 
        new HashMap<ActivityInfo, List<? extends IntentFilter> >();
    public static  Map<ComponentName, ServiceInfo> sServiceInfoMap = 
        new HashMap<ComponentName, ServiceInfo>();
    public static  Map<ActivityInfo, List<? extends IntentFilter> > sReceiverFiltersCache = 
        new HashMap<ActivityInfo, List<? extends IntentFilter> >();
    public static List<ProviderInfo> sProviderInfos = new ArrayList<>();
    public static String processName;

    public static Intent loadApkAndGetLaunchIntent(File apkFile) throws Exception {
        // get activityThread
        Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
        Method currentActivityThreadMethod = activityThreadClass.getDeclaredMethod("currentActivityThread");
        currentActivityThreadMethod.setAccessible(true);
        Object currentActivityThread = currentActivityThreadMethod.invoke(null);

        // get DEFAULT_COMPATIBILITY_INFO
        Class<?> compatibilityInfoClass = Class.forName("android.content.res.CompatibilityInfo");
        Field defaultCompatibilityInfoField = compatibilityInfoClass.getDeclaredField("DEFAULT_COMPATIBILITY_INFO");
        defaultCompatibilityInfoField.setAccessible(true);

        Object defaultCompatibilityInfo = defaultCompatibilityInfoField.get(null);

        // get applicationInfo
        Class<?> packageParserClass = Class.forName("android.content.pm.PackageParser");
        Class<?> packageParser$PackageClass = Class.forName("android.content.pm.PackageParser$Package");
        Class<?> packageUserStateClass = Class.forName("android.content.pm.PackageUserState");

        Method generateApplicationInfoMethod = packageParserClass.getDeclaredMethod("generateApplicationInfo",
                packageParser$PackageClass, int.class, packageUserStateClass);

        Object packageParser = packageParserClass.newInstance();
        Method parsePackageMethod = packageParserClass.getDeclaredMethod("parsePackage", File.class, int.class);
        Object packageObj = parsePackageMethod.invoke(packageParser, apkFile, 0);

        Object defaultUserState = packageUserStateClass.newInstance();
        ApplicationInfo applicationInfo = (ApplicationInfo) generateApplicationInfoMethod.invoke(packageParser,
                packageObj, 0, defaultUserState);
        String apkPath = apkFile.getPath();
        applicationInfo.sourceDir = apkPath;
        applicationInfo.publicSourceDir = apkPath;
        processName = applicationInfo.packageName;

        // get loadedApk
        Method getPackageInfoNoCheckMethod = activityThreadClass.getDeclaredMethod("getPackageInfoNoCheck",
                ApplicationInfo.class, compatibilityInfoClass);
        Object loadedApk = getPackageInfoNoCheckMethod.invoke(currentActivityThread, applicationInfo, defaultCompatibilityInfo);

        String odexPath = Util.getPluginOptDexDir(applicationInfo.packageName).getPath();
        String libDir = Util.getPluginLibDir(applicationInfo.packageName).getPath();

        Field mClassLoaderField = loadedApk.getClass().getDeclaredField("mClassLoader");
        mClassLoaderField.setAccessible(true);

        // new ClassLoader for apk
        ClassLoader classLoader = new CustomClassLoader(apkFile.getPath(), odexPath, libDir, ClassLoader.getSystemClassLoader());

        // hook  classLoader
        mClassLoaderField.set(loadedApk, classLoader);

        // save to local
        sLoadedApk.put(applicationInfo.packageName, loadedApk);
        sLoadedClassLoaders.put(applicationInfo.packageName, classLoader);

        // get apk packageName
        Field packageNameFiled = packageParser$PackageClass.getDeclaredField("packageName");
        packageNameFiled.setAccessible(true);
        String pkgName = (String) packageNameFiled.get(packageObj);

        // get activities;
        Field activitiesFiled = packageParser$PackageClass.getDeclaredField("activities");
        activitiesFiled.setAccessible(true);
        List<?> activities  = (List)activitiesFiled.get(packageObj);

        // get receivers
        Field receiversField = packageParser$PackageClass.getDeclaredField("receivers");
        receiversField.setAccessible(true);
        List<?> receivers = (List)receiversField.get(packageObj);
        //
        // get services
        Field servicesFiled = packageParser$PackageClass.getDeclaredField("services");
        servicesFiled.setAccessible(true);
        List<?> services = (List)servicesFiled.get(packageObj);

        // get providers
        Field providersField = packageParser$PackageClass.getDeclaredField("providers");
        providersField.setAccessible(true);
        List providers = (List)providersField.get(packageObj);


        // get activityinfos and intentfilters
        Class<?> packageParser$Activity = Class.forName("android.content.pm.PackageParser$Activity");
        Class<?> componentClass = packageParser$Activity.getSuperclass();
        Field classNameFiled = componentClass.getDeclaredField("className");
        classNameFiled.setAccessible(true);
        String className = (String)classNameFiled.get(activities.get(0));

        Field intentsField = componentClass.getDeclaredField("intents");
        intentsField.setAccessible(true);

        Class<?> userHandlerClass = Class.forName("android.os.UserHandle");

        Method getCallingUserIdMethod = userHandlerClass.getDeclaredMethod("getCallingUserId");
        int userId = (Integer)getCallingUserIdMethod.invoke(null);
        Method generateReceiverInfoMethod = packageParserClass.getDeclaredMethod("generateActivityInfo", 
                packageParser$Activity, int.class, packageUserStateClass, int.class);
        for (Object activity : activities) {
            ActivityInfo info = (ActivityInfo) generateReceiverInfoMethod.invoke(packageParser, activity, 0, defaultUserState, userId);
            List<? extends IntentFilter> filters = (List<? extends IntentFilter>) intentsField.get(activity);
            sActivityFiltersCache.put(info, filters);
        }

        // get receivers and actions
        for (Object receiver : receivers) {
            ActivityInfo info = (ActivityInfo) generateReceiverInfoMethod.invoke(packageParser, receiver, 0, defaultUserState, userId);
            List<? extends IntentFilter> filters = (List<? extends IntentFilter>) intentsField.get(receiver);
            sReceiverFiltersCache.put(info, filters);
        }

        // get serviceinfos
        Class<?> packageParser$Service = Class.forName("android.content.pm.PackageParser$Service");
        Method generateServiceInfo = packageParserClass.getDeclaredMethod("generateServiceInfo", 
                packageParser$Service, int.class, packageUserStateClass, int.class);
        for (Object service : services) {
            ServiceInfo info = (ServiceInfo)generateServiceInfo.invoke(packageParser, service, 0, defaultUserState, userId);
            sServiceInfoMap.put(new ComponentName(info.packageName, info.name), info);
        }

        // get providerinfos
        Class<?> packageParser$ProviderClass = Class.forName("android.content.pm.PackageParser$Provider");
        Method generateProviderInfo = packageParserClass.getDeclaredMethod("generateProviderInfo",
                packageParser$ProviderClass, int.class, packageUserStateClass, int.class);
        for (Object provider : providers) {
            ProviderInfo info = (ProviderInfo)generateProviderInfo.invoke(packageParser, provider, 0, defaultUserState, userId);
            sProviderInfos.add(info);
        }


        Intent intent = new Intent();
        intent.setComponent(new ComponentName(pkgName, className));
        return intent;

    }
}

