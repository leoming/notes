package com.example.syberos.demo3;

import android.app.Activity;

public class StubActivity extends Activity {
}
