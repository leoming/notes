package com.example.zmm.appjni;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class AppJniActivity extends Activity {
    private static final String TAG = "AppJniActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_app_jni);
        TextView textView = (TextView) findViewById (R.id.tv);
        Log.d (TAG, "==========CALL SHOW==========");
        String jniStr = show ();
        Log.d (TAG, jniStr);
        textView.setText (jniStr);
        Log.d (TAG, "======================");
    }

    private native String show();
    public void callback() {
        Log.d (TAG, "call back from native");
        throw new  NullPointerException();
    }

    static {
        System.loadLibrary ("app_jni");
    }
}
