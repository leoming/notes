//
// Created by zmm on 17-1-17.
//
#include "com_example_zmm_appjni_AppJniActivity.h"
#include <string.h>

jstring Java_com_example_zmm_appjni_AppJniActivity_show
  (JNIEnv *env, jobject obj) {
      jclass jcls = env->GetObjectClass(obj);
      if (jcls != NULL) {
          jmethodID jmID = env->GetMethodID(jcls, "callback", "()V"); //注意大小写，调了好久
          if (jmID != NULL) {
              env->CallVoidMethod(obj, jmID);
          }
      }

      if (env->ExceptionCheck()) {
          env->ExceptionDescribe();
          env->ExceptionClear();
      }
      return env->NewStringUTF("Show message from JNI");
  }

